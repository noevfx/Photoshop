const { app, core, action, constants } = require("photoshop");
const fs = require("uxp").storage.localFileSystem;

// ---------------------------------------------------------------------
// UI State & Preferences
// ---------------------------------------------------------------------

const state = {
    options: {
        removeMasks: false,
        removeInvisible: false,
        removeStyles: false
    },
    outputFolderEntry: null,
    outputFolderPath: "",
    destinationMode: "auto",
    destinationDocumentPath: ""
};

const STORAGE_KEY = "exportArtboards.options";

function loadOptions() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
            const saved = JSON.parse(raw);
            for (const k in saved) {
                if (state.options.hasOwnProperty(k)) {
                    state.options[k] = saved[k];
                }
            }
        }
    } catch (e) {
        console.error("Error loading options:", e);
    }
}

function saveOptions() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state.options));
    } catch (e) {
        console.error("Error saving options:", e);
    }
}

function renderOptions() {
    document.querySelectorAll(".option-row").forEach(function (row) {
        const key = row.getAttribute("data-option");
        row.classList.toggle("checked", !!state.options[key]);
    });
}

function bindOptionRows() {
    document.querySelectorAll(".option-row").forEach(function (row) {
        row.addEventListener("click", function () {
            const key = row.getAttribute("data-option");
            state.options[key] = !state.options[key];
            saveOptions();
            renderOptions();
        });
    });
}

function bindPanelToggle() {
    document.querySelectorAll(".panel-header").forEach(function (header) {
        header.addEventListener("click", function () {
            const id = header.getAttribute("data-toggle");
            const panel = document.getElementById(id);
            if (panel) {
                panel.classList.toggle("collapsed");
            }
        });
    });
}

function updateFolderLabel() {
    const el = document.getElementById("folderInput");
    if (state.outputFolderPath) {
        el.textContent = state.outputFolderPath;
        el.classList.remove("placeholder");
        el.title = state.outputFolderPath;
    } else {
        el.textContent = "No destination folder selected";
        el.classList.add("placeholder");
        el.title = "";
    }
}

async function chooseFolder() {
    try {
        const folder = await fs.getFolder();
        if (folder) {
            state.outputFolderEntry = folder;
            state.outputFolderPath = folder.nativePath;
            state.destinationMode = "manual";
            state.destinationDocumentPath = app.activeDocument ? app.activeDocument.path : "";
            updateFolderLabel();
        }
    } catch (e) {
        // User cancelled folder picker
    }
}

function getDocumentFolderPath(documentPath) {
    if (!documentPath || typeof documentPath !== "string") return null;

    // Local Windows/macOS files only. Cloud-document identifiers are not usable
    // as a native folder URL.
    const normalized = documentPath.replace(/\\/g, "/");
    const isWindowsPath = /^[A-Za-z]:\//.test(normalized);
    const isMacPath = normalized.charAt(0) === "/";
    if (!isWindowsPath && !isMacPath) return null;

    const lastSlash = normalized.lastIndexOf("/");
    return lastSlash > 0 ? normalized.slice(0, lastSlash) : null;
}

async function useDocumentFolderAsDestination(doc) {
    if (!doc) return;

    const documentPath = doc.path || "";
    const folderPath = getDocumentFolderPath(documentPath);
    if (!folderPath) return;

    // Preserve a folder the user explicitly chose while working in the same PSD.
    if (state.destinationMode === "manual" && state.destinationDocumentPath === documentPath) {
        return;
    }

    // Avoid resolving the same filesystem entry on every UI refresh.
    if (state.destinationMode === "auto" &&
        state.destinationDocumentPath === documentPath &&
        state.outputFolderEntry) {
        return;
    }

    try {
        // UXP expects a file URL. On Windows this becomes file:/C:/... .
        const folderUrl = "file:/" + encodeURI(folderPath.replace(/^\/+/, ""));
        const folder = await fs.getEntryWithUrl(folderUrl);
        if (folder) {
            state.outputFolderEntry = folder;
            state.outputFolderPath = folder.nativePath || folderPath;
            state.destinationMode = "auto";
            state.destinationDocumentPath = documentPath;
            updateFolderLabel();
        }
    } catch (e) {
        // Unsaved/cloud documents or restricted locations simply keep the
        // destination empty so the user can choose one manually.
    }
}

function showResult(box, message, isError) {
    box.textContent = message;
    box.classList.remove("success", "error");
    box.classList.add("show", isError ? "error" : "success");
}

function hideResult(box) {
    box.classList.remove("show", "success", "error");
}

// ---------------------------------------------------------------------
// Artboard Detection & Document Status
// ---------------------------------------------------------------------

async function isLayerArtboard(layer) {
    if (!layer) return false;
    if (layer.isArtboard === true) return true;

    try {
        const res = await action.batchPlay(
            [
                {
                    _obj: "get",
                    _target: [
                        { _property: "artboardEnabled" },
                        { _ref: "layer", _id: layer.id }
                    ],
                    _options: { dialogOptions: "dontDisplay" }
                }
            ],
            { synchronousExecution: true, dialogOptions: "dontDisplay" }
        );

        if (res && res[0] && (res[0].artboardEnabled === true || res[0].artboard !== undefined)) {
            return true;
        }
    } catch (e) {}

    return false;
}

async function collectArtboards(doc) {
    const result = [];
    if (!doc || !doc.layers) return result;

    for (let i = 0; i < doc.layers.length; i++) {
        const lyr = doc.layers[i];
        const isArt = await isLayerArtboard(lyr);
        if (isArt) {
            result.push({
                index: i,
                id: lyr.id,
                name: lyr.name
            });
        }
    }
    return result;
}

async function refreshState() {
    const wrapper = document.getElementById("docStatus");
    const name = document.getElementById("docName");
    const meta = document.getElementById("docMeta");
    const btnRun = document.getElementById("btnRun");
    const btnRefresh = document.getElementById("btnRefresh");

    wrapper.classList.remove("ok", "warn", "loading");
    btnRefresh.classList.add("refreshing");
    wrapper.classList.add("loading");

    const doc = app.activeDocument;
    if (!doc) {
        wrapper.classList.remove("loading");
        wrapper.classList.add("warn");
        name.textContent = "No document open";
        meta.textContent = "Open a PSD containing artboards";
        btnRun.disabled = true;
        btnRefresh.classList.remove("refreshing");
        return;
    }

    name.textContent = doc.title;

    try {
        await useDocumentFolderAsDestination(doc);
        const artboards = await collectArtboards(doc);
        if (artboards.length === 0) {
            wrapper.classList.remove("loading");
            wrapper.classList.add("warn");
            meta.textContent = "No artboards found in this document";
            btnRun.disabled = true;
        } else {
            wrapper.classList.remove("loading");
            wrapper.classList.add("ok");
            meta.textContent = `${artboards.length} artboard(s) found`;
            btnRun.disabled = false;
        }
    } catch (err) {
        wrapper.classList.remove("loading");
        wrapper.classList.add("warn");
        meta.textContent = "Error reading artboards";
        btnRun.disabled = true;
    } finally {
        btnRefresh.classList.remove("refreshing");
    }
}

// ---------------------------------------------------------------------
// Document Operations & Cleaning Routines
// ---------------------------------------------------------------------

function padNumber(num, size) {
    let s = String(num);
    while (s.length < size) s = "0" + s;
    return s;
}

// Force delete any layer or artboard using batchPlay ID
async function deleteLayer(layer) {
    if (!layer) return;
    try {
        if (layer.locked) layer.locked = false;
    } catch (e) {}

    try {
        await action.batchPlay(
            [
                {
                    _obj: "delete",
                    _target: [{ _ref: "layer", _id: layer.id }],
                    _options: { dialogOptions: "dontDisplay" }
                }
            ],
            { synchronousExecution: true, dialogOptions: "dontDisplay" }
        );
    } catch (err) {
        try {
            await layer.delete();
        } catch (e) {}
    }
}

// 1. Remove Layer & Vector Masks safely
async function deleteLayerMasks(doc, lyr) {
    try {
        const props = await action.batchPlay(
            [
                {
                    _obj: "get",
                    _target: [{ _ref: "layer", _id: lyr.id }],
                    _options: { dialogOptions: "dontDisplay" }
                }
            ],
            { synchronousExecution: true, dialogOptions: "dontDisplay" }
        );

        if (props && props[0]) {
            const data = props[0];
            const hasUserMask = !!(data.hasUserMask || data.hasLayerMask);
            const hasVectorMask = !!data.hasVectorMask;

            if (hasUserMask) {
                try {
                    await action.batchPlay(
                        [
                            {
                                _obj: "delete",
                                _target: [
                                    {
                                        _ref: "channel",
                                        _enum: "channel",
                                        _value: "mask"
                                    },
                                    {
                                        _ref: "layer",
                                        _id: lyr.id
                                    }
                                ],
                                _options: { dialogOptions: "dontDisplay" }
                            }
                        ],
                        { synchronousExecution: true, dialogOptions: "dontDisplay" }
                    );
                } catch (e) {}
            }

            if (hasVectorMask) {
                try {
                    await action.batchPlay(
                        [
                            {
                                _obj: "delete",
                                _target: [
                                    {
                                        _ref: "path",
                                        _enum: "path",
                                        _value: "vectorMask"
                                    },
                                    {
                                        _ref: "layer",
                                        _id: lyr.id
                                    }
                                ],
                                _options: { dialogOptions: "dontDisplay" }
                            }
                        ],
                        { synchronousExecution: true, dialogOptions: "dontDisplay" }
                    );
                } catch (e) {}
            }
        }
    } catch (e) {}
}

async function removeAllLayerMasks(doc, container) {
    if (!container || !container.layers) return;
    for (let i = 0; i < container.layers.length; i++) {
        const lyr = container.layers[i];
        await deleteLayerMasks(doc, lyr);
        if (lyr.layers && lyr.layers.length > 0) {
            await removeAllLayerMasks(doc, lyr);
        }
    }
}

// 2. Remove Hidden / Invisible Layers safely
async function removeInvisibleLayers(container) {
    if (!container || !container.layers) return;
    for (let i = container.layers.length - 1; i >= 0; i--) {
        const lyr = container.layers[i];
        if (lyr.layers && lyr.layers.length > 0) {
            if (lyr.visible) {
                await removeInvisibleLayers(lyr);
            } else {
                await deleteLayer(lyr);
            }
        } else {
            if (!lyr.visible) {
                await deleteLayer(lyr);
            }
        }
    }
}

// 3. Remove Layer Styles safely
async function getLayerEffects(lyr) {
    const props = await action.batchPlay(
        [{
            _obj: "get",
            _target: [
                { _property: "layerEffects" },
                { _ref: "layer", _id: lyr.id }
            ],
            _options: { dialogOptions: "silent" }
        }],
        { continueOnError: true, dialogOptions: "silent" }
    );

    if (!props || !props[0] || props[0]._obj === "error") return null;
    return props[0].layerEffects || null;
}

function hasActiveLayerEffects(effects) {
    if (!effects) return false;
    // Photoshop also returns bookkeeping keys (for example masterFXSwitch,
    // globalLightingAngle and scale) after an effect stack has been cleared.
    // Only the following keys represent visible Layer Style effects.
    const visibleEffectKeys = [
        "bevelEmboss", "innerShadow", "innerGlow", "satin", "chromeFX",
        "solidFill", "gradientFill", "patternFill", "outerGlow", "dropShadow",
        "frameFX", "dropShadowMulti", "innerShadowMulti"
    ];
    return visibleEffectKeys.some(function (key) {
        return Object.prototype.hasOwnProperty.call(effects, key);
    });
}

async function clearLayerStyle(doc, lyr) {
    const currentEffects = await getLayerEffects(lyr);
    if (!hasActiveLayerEffects(currentEffects)) return;

    // First target the layer by its stable ID.
    await action.batchPlay(
        [{
            _obj: "select",
            _target: [{ _ref: "layer", _id: lyr.id }],
            makeVisible: false,
            _options: { dialogOptions: "silent" }
        }],
        { synchronousExecution: true, dialogOptions: "silent" }
    );

    // Exact actionJSON recorded in Photoshop 27.9.1 through
    // Plugins > Development > Record Action Commands while invoking
    // Layer > Layer Style > Clear Layer Style.
    const clearResult = await action.batchPlay(
        [{
            _obj: "disableLayerStyle",
            _target: [{ _enum: "ordinal", _ref: "layer" }],
            _options: { dialogOptions: "silent" }
        }],
        { synchronousExecution: true, continueOnError: true, dialogOptions: "silent" }
    );

    if (clearResult && clearResult[0] && clearResult[0]._obj === "error") {
        const detail = clearResult[0].message || clearResult[0]._message || "disableLayerStyle failed";
        throw new Error(`Photoshop could not clear layer styles from "${lyr.name}": ${detail}`);
    }

    const remainingEffects = await getLayerEffects(lyr);
    if (hasActiveLayerEffects(remainingEffects)) {
        throw new Error(`Clear Layer Style left visible effects on "${lyr.name}".`);
    }
}

async function removeAllLayerStyles(doc, container) {
    if (!container || !container.layers) return;
    for (let i = 0; i < container.layers.length; i++) {
        const lyr = container.layers[i];
        await clearLayerStyle(doc, lyr);
        if (lyr.layers && lyr.layers.length > 0) {
            await removeAllLayerStyles(doc, lyr);
        }
    }
}

// 4. Save and close document
async function saveDocAsPSD(doc, folderEntry, fileName) {
    const fileEntry = await folderEntry.createFile(fileName, { overwrite: true });

    try {
        if (doc.saveAs && doc.saveAs.psd) {
            await doc.saveAs.psd(fileEntry, { maximizeCompatibility: true });
            return;
        }
    } catch (saveErr) {}

    const token = await fs.createSessionToken(fileEntry);
    await action.batchPlay(
        [
            {
                _obj: "save",
                as: {
                    _obj: "photoshop35Format",
                    maximizeCompatibility: true
                },
                in: {
                    _path: token,
                    _kind: "local"
                },
                documentID: doc.id,
                lowerCase: true,
                _options: { dialogOptions: "dontDisplay" }
            }
        ],
        { synchronousExecution: true, dialogOptions: "dontDisplay" }
    );
}

async function closeDocumentSafely(doc) {
    try {
        if (doc.closeWithoutSaving) {
            await doc.closeWithoutSaving();
            return;
        }
    } catch (e) {}

    try {
        if (doc.close) {
            await doc.close(constants.SaveOptions.DONOTSAVECHANGES);
            return;
        }
    } catch (e) {}

    try {
        await action.batchPlay(
            [
                {
                    _obj: "close",
                    saving: {
                        _enum: "yesNo",
                        _value: "no"
                    },
                    documentID: doc.id,
                    _options: { dialogOptions: "dontDisplay" }
                }
            ],
            { synchronousExecution: true, dialogOptions: "dontDisplay" }
        );
    } catch (e) {}
}

// ---------------------------------------------------------------------
// Main Export Routine
// ---------------------------------------------------------------------

async function runExport() {
    const btnRun = document.getElementById("btnRun");
    const resultBox = document.getElementById("resultBox");

    hideResult(resultBox);

    const srcDoc = app.activeDocument;
    if (!srcDoc) {
        showResult(resultBox, "No document is currently active.", true);
        return;
    }

    const artboards = await collectArtboards(srcDoc);
    if (artboards.length === 0) {
        showResult(resultBox, "No artboards found in this document.", true);
        return;
    }

    if (!state.outputFolderEntry) {
        showResult(resultBox, "Please choose a destination folder before running.", true);
        return;
    }

    const baseName = srcDoc.title.replace(/\.[^.]+$/, "");
    const folderEntry = state.outputFolderEntry;
    const options = { ...state.options };

    btnRun.disabled = true;
    btnRun.classList.add("loading");
    btnRun.textContent = "Exporting...";

    try {
        await core.executeAsModal(
            async () => {
                let count = 0;

                for (let i = 0; i < artboards.length; i++) {
                    count++;
                    const pageNum = padNumber(count, 2);
                    const outName = `${baseName} - PG ${pageNum}.psd`;
                    let newDoc = null;

                    try {
                        // Ensure source document is the active one
                        app.activeDocument = srcDoc;

                        // Duplicate the source document
                        await action.batchPlay(
                            [
                                {
                                    _obj: "duplicate",
                                    _target: [{ _ref: "document", _id: srcDoc.id }],
                                    name: outName,
                                    _options: { dialogOptions: "dontDisplay" }
                                }
                            ],
                            { synchronousExecution: true, dialogOptions: "dontDisplay" }
                        );

                        newDoc = app.activeDocument;
                        if (!newDoc || newDoc.id === srcDoc.id) {
                            throw new Error(`Failed to clone document for artboard: ${artboards[i].name}`);
                        }

                        // Identify target artboard index in newDoc
                        const targetArtboardIndex = artboards[i].index;

                        // Delete all other top-level layers/artboards using batchPlay delete
                        for (let j = newDoc.layers.length - 1; j >= 0; j--) {
                            if (j !== targetArtboardIndex) {
                                const lyrToDelete = newDoc.layers[j];
                                await deleteLayer(lyrToDelete);
                            }
                        }

                        // Apply cleaning options on the isolated artboard document
                        if (options.removeInvisible) {
                            await removeInvisibleLayers(newDoc);
                        }
                        if (options.removeStyles) {
                            await removeAllLayerStyles(newDoc, newDoc);
                        }
                        if (options.removeMasks) {
                            await removeAllLayerMasks(newDoc, newDoc);
                        }

                        // Save PSD
                        await saveDocAsPSD(newDoc, folderEntry, outName);
                    } finally {
                        // Never leave a generated PSD open when cleanup or save fails.
                        if (newDoc && newDoc.id !== srcDoc.id) {
                            await closeDocumentSafely(newDoc);
                        }
                    }
                }

                return count;
            },
            { commandName: "Export Artboards UXP" }
        );

        showResult(
            resultBox,
            `Successfully exported ${artboards.length} artboard(s) to:\n${state.outputFolderPath}`,
            false
        );
    } catch (e) {
        showResult(resultBox, "Export error: " + (e && e.message ? e.message : String(e)), true);
    }

    btnRun.classList.remove("loading");
    btnRun.textContent = "Export Artboards";
    btnRun.disabled = false;
    await refreshState();
}

// ---------------------------------------------------------------------
// Initialization
// ---------------------------------------------------------------------

function init() {
    // Hide Photoshop's native floating-panel resize strip/gripper.
    core.suppressResizeGripper({
        type: "panel",
        target: "exportArtboardsPanel",
        value: true
    }).catch(function () {});

    loadOptions();
    renderOptions();
    bindOptionRows();
    bindPanelToggle();
    updateFolderLabel();

    document.getElementById("btnRefresh").addEventListener("click", refreshState);
    document.getElementById("btnChooseFolder").addEventListener("click", chooseFolder);
    document.getElementById("btnRun").addEventListener("click", runExport);

    refreshState();
}

let initialized = false;
function initOnce() {
    if (initialized) return;
    initialized = true;
    init();
}

document.addEventListener("DOMContentLoaded", initOnce);

if (document.readyState === "complete" || document.readyState === "interactive") {
    initOnce();
}
