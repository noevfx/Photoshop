# Export Artboards (Photoshop UXP Plugin)

Version 1.3.3 preserves the working artboard export flow and uses the exact
Clear Layer Style actionJSON recorded by Photoshop 27.9.1. It also refines panel
spacing, status indicators, Refresh button, overflow behavior, hides the native
resize gripper, and automatically selects the active PSD's folder as destination.

A dockable UXP panel for Adobe Photoshop. Exports each Artboard of the active document into a separate PSD file with automatic numbering and optional layer cleanup (removing layer/vector masks, removing invisible layers, and clearing layer styles).

Output naming pattern: `<Document Name> - PG 01.psd`, `- PG 02.psd`, etc.

## Project Structure

```
Export Artboards UXP/
  manifest.json     -> Plugin manifest descriptor for Photoshop
  index.html        -> Modern panel user interface
  css/style.css     -> Dark Adobe-themed responsive styling
  js/main.js        -> Core logic (Photoshop DOM API + batchPlay)
```

## Test installation (Developer Mode)

1. Open **UXP Developer Tools** (available via Adobe Creative Cloud).
2. Click **Add Plugin...** and choose the `manifest.json` file inside `Export Artboards UXP`.
3. With Photoshop open, click **Load** (or **Watch**).
4. In Photoshop, access the panel via **Plugins > Export Artboards**.

## Permanent installation (without Developer Tools)

1. In **UXP Developer Tool**, use the three-dot menu beside the plugin and choose
   **Package**. This creates an Adobe `.ccx` installer.
2. Double-click the generated `.ccx` file and select **Install locally** in
   Adobe Creative Cloud.
3. Restart Photoshop. The panel will then be available from
   **Plugins > Export Artboards** without loading it in Developer Tools again.

Photoshop normally restores a panel that was left open/docked when it closes.

## Features & Options

- **Automatic Artboard Detection**: Accurately queries `artboardEnabled` metadata.
- **Remove Layer Masks**: Removes raster pixel masks and vector masks from all layers.
- **Remove Hidden Layers**: Recursively purges invisible layers and groups.
- **Remove Layer Styles**: Clears blending options, strokes, shadows, and color overlays.
- **Output Destination**: Defaults to the folder containing the active PSD; use
  **Browse** to override it for that document.
